package com.example.bss_lb1_3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

//    var b1: Button? = null
//    var b2: Button? = null
//    var b3: Button? = null
//    var b4: Button? = null
//    var b5: Button? = null
//    var b6: Button? = null
//    var b7: Button? = null
//    var b8: Button? = null
//    var b9: Button? = null
//    var b0: Button? = null
//    var bPlus: Button? = null
//    var bMinus: Button? = null
//    var bEqual: Button? = null
//    var bDivide: Button? = null
//    var bMultiply: Button? = null
//    var bPoint: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var b1 = findViewById<Button>(R.id.b1)
        var b2 = findViewById<Button>(R.id.b2)
        var b3 = findViewById<Button>(R.id.b3)
        var b4 = findViewById<Button>(R.id.b4)
        var b5 = findViewById<Button>(R.id.b5)
        var b6 = findViewById<Button>(R.id.b6)
        var b7 = findViewById<Button>(R.id.b7)
        var b8 = findViewById<Button>(R.id.b8)
        var b9 = findViewById<Button>(R.id.b9)
        var b0 = findViewById<Button>(R.id.b0)
        var bPlus = findViewById<Button>(R.id.bPlus)
        var bMinus = findViewById<Button>(R.id.bMinus)
        var bEqual = findViewById<Button>(R.id.bEqual)
        var bMultiply = findViewById<Button>(R.id.bMultiply)
        var bDivide = findViewById<Button>(R.id.bDivide)
        var bPoint = findViewById<Button>(R.id.bPoint)
        var tvScreen = findViewById<TextView>(R.id.tvScreen)

        b1.setOnClickListener {
            numberButtonHandler(b1, tvScreen)
        }

        b2.setOnClickListener {
            numberButtonHandler(b2, tvScreen)
        }

        b3.setOnClickListener {
            numberButtonHandler(b3, tvScreen)
        }

        b4.setOnClickListener {
            numberButtonHandler(b4, tvScreen)
        }

        b5.setOnClickListener {
            numberButtonHandler(b5, tvScreen)
        }

        b6.setOnClickListener {
            numberButtonHandler(b6, tvScreen)
        }

        b7.setOnClickListener {
            numberButtonHandler(b7, tvScreen)
        }

        b8.setOnClickListener {
            numberButtonHandler(b8, tvScreen)
        }

        b9.setOnClickListener {
            numberButtonHandler(b9, tvScreen)
        }

        b0.setOnClickListener {
            numberButtonHandler(b0, tvScreen)
        }

//        b1.setOnClickListener {view ->
//
//        }

    }

    private fun numberButtonHandler(button: Button, screen: TextView) {
        screen.text = screen.text + button.text
    }
}